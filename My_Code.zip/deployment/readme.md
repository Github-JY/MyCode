本目录下为一些端侧部署工具及代码。

# 数据集转换工具

https://github.com/RapidAI/YOLO2COCO

# onnx 目录
  存放onnx转换脚本以及c++ 推理代码
 
# ncnn  目录
  存放ncnn相关的推理代码及模性转换教程
