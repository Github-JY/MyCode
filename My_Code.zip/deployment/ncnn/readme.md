转换方法：



1. 参考上一级目录下的onnx中的转换脚本，它将转为onnx模型
2. 按这个指导[转换成ncnn模型](https://mp.weixin.qq.com/s/Sv8BXiXbvnEyzpVseY90VA)

